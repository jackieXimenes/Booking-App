<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Servico;

class ServicoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }
    public function getServicos(){
        return response()->json([
            ["id_servicos" => 1, "nome_servicos" => "Corte"],
            ["id_servicos" => 2, "nome_servicos" => "Barba"],
            ["id_servicos" => 3, "nome_servicos" => "pe"],
            ["id_servicos" => 5, "nome_servicos" => "corte e pe"],
            ["id_servicos" => 6, "nome_servicos" => "corte e barba"],
            ["id_servicos" => 7, "nome_servicos" => "barba e pe"],
            ["id_servicos" => 4, "nome_servicos" => "completo"],
            ["id_servicos" => 8, "nome_servicos" => ""],
            ["id_servicos" => 9, "nome_servicos" => "Bruno"],
            ["id_servicos" => 10, "nome_servicos" => "Josué"],
            ["id_servicos" => 11, "nome_servicos" => "Matheus"],
            ["id_servicos" => 12, "nome_servicos" => "Ludi"]
        ]);
    }
}
