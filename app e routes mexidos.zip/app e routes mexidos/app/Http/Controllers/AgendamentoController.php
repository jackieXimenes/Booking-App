<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\agendamento;

class AgendamentoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }

    public function getAgendamento(){
        return response()->json([
            ["id_Agenda"=> 1, "Dia"=> "11/05/2025", "hora"=> "8:00", "nome_cliente"=> "Bell hoocks", "nome_funcionario"=> "jackie Ximenes"],

            ["id_Agenda"=> 2, "Dia"=> "03/05/2025", "hora"=> "8:30", "nome_cliente"=> "Ailton Krenak" , "nome_funcionario"=> "Matheus felipe"], 

            ["id_Agenda"=> 3, "Dia"=> "06/05/2025", "hora"=> "9:00", "nome_cliente"=> "Machado de Assis", "nome_funcionario"=> "Ian Ian"],

            ["id_Agenda"=> 4, "Dia"=> "15/05/2025", "hora"=> "9:30", "nome_cliente"=> "Nise Da Silveira","nome_funcionario"=> "jackie Ximenes"],

            ["id_Agenda"=> 5, "Dia"=> "21/05/2025", "hora"=> "10:00", "nome_cliente"=> "Nizia Floresta", "nome_funcionario"=> "Ian Ian"],

            ["id_Agenda"=> 6, "Dia"=> "08/05/2025", "hora"=> "10:30", "nome_cliente"=> "Jorge Ben Jor", "nome_funcionario"=> " Klynder boeno"],

            ["id_Agenda"=> 7, "Dia"=> '22/05/2025', "hora"=> "11:00", "nome_cliente"=> "Erica hilton", "nome_funcionario"=> "jackie Ximenes"], 

            ["id_Agenda"=> 8, "Dia"=> "30/05/2025", "hora"=> "12:30", "nome_cliente"=> "Biello", "nome_funcionario"=> "Matheus felipe"],

            ["id_Agenda"=> 9, "Dia"=> "24/05/2025", "hora"=> "13:00", "nome_cliente"=> "Rita drag", "nome_funcionario"=> " Klynder boeno"],

            ["id_Agenda"=> 10, "Dia"=> "02/05/2025", "hora"=> "13:00", "nome_cliente"=> "Rafael de assis",  "nome_funcionario"=> " Brian"]
        ]);
    }
}
